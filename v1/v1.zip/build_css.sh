sass scss/grayscale.scss:css/grayscale.min.css --style compressed 
uglifyjs js/grayscale.js -o js/grayscale.min.js